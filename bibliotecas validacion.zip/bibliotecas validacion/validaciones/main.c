#include <stdio.h>
#include <stdlib.h>

/** \brief
 * getIntCompleta()
 * \param mensaje[] char mensaje de pedido e datos
 * \param mensajeError[] char mensaje de error
 * \param intentos int cantidad de posibilidades
 * \param maximo int el maximo numero posible
 * \param minimo int el minimo numero posible
 * \return int numero entero
 *
 */

int getIntCompleta(char mensaje[],char mensajeError[],int intentos,int maximo,int minimo);

/** \brief
 *
 * \param mensaje[] char
 * \param maximo int
 * \param minimo int
 * \param resp int*
 * \return int
 *
 */
int getIntEntreMinMax(char mensaje[],int maximo,int minimo,int *resp);

int main()
{
    int edad=0;
    int sueldo;
    int respuesta;

    edad= getIntCompleta("ingrese edad:","no es una edad valida",5,120,1);
    printf("edad %d\n",edad);


    respuesta=getIntEntreMinMax("ingrese sueldo: \n",9000,150,&sueldo);
    if(respuesta==0)
    {
        printf("correcto!\n sueldo: %d\n",sueldo);
    }
    else
    {
        if(respuesta<0)
        {
            printf("ERROR,sueldo menor al minimo\n");
        }
        else
        {
            printf("ERROR,sueldo mayor al maximo\n");
        }
    }
    return 0;
}

int getIntCompleta(char mensaje[],char mensajeError[],int intentos,int maximo,int minimo)
{
    int retorno=0;
    do
    {
        printf("%s",mensaje);
        setbuf(stdin,NULL);
        scanf("%d",&retorno);
        if(retorno>maximo || retorno<minimo)
        {
            printf("%s\n",mensajeError);
        }
        else
            break;
    intentos--;
    }
    while(intentos>0);
    return retorno;
}

int getIntEntreMinMax(char mensaje[],int maximo,int minimo,int *resp)
{
    int retorno=0;

    printf("%s",mensaje);
    setbuf(stdin,NULL);
    scanf("%d",resp);
    if(*resp<minimo)
    {
        retorno=-1;
    }
    else
    {
        if(*resp>maximo)
        {
            retorno=1;
        }
        else
        {
            retorno=0;
        }
    }
    return retorno;

}
